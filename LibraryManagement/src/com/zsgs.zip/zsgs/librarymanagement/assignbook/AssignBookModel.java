package com.zsgs.librarymanagement.assignbook;

public class AssignBookModel {

	private AssignBookView assignBookView;
	
	public AssignBookModel(AssignBookView assignBookView) {
		this.assignBookView = assignBookView; 
	}

	
}
