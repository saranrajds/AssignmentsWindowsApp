package com.zsgs.librarymanagement.assignbook;

public class AssignBookView {

	private AssignBookModel assignBookModel;
	
	AssignBookView() {
		assignBookModel = new AssignBookModel(this);
	}
}
