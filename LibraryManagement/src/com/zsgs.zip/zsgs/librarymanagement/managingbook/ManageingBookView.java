package com.zsgs.librarymanagement.managingbook;

public class ManageingBookView {

	private ManageingBookModel manageingBookModel;
	public ManageingBookView() {
		manageingBookModel = new ManageingBookModel(this);
	}
}
