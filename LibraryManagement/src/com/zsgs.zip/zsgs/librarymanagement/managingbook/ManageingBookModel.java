package com.zsgs.librarymanagement.managingbook;

public class ManageingBookModel {

	private ManageingBookView manageingBookView;
	
	public ManageingBookModel(ManageingBookView manageingBookView) {
		this.manageingBookView = manageingBookView;
	}
}
