package com.zsgs.librarymanagement;

import com.zsgs.librarymanagement.login.LoginView;

public class LibraryManagement {

	public static void main(String[] args) {
		
		LoginView loginView = new LoginView();
		loginView.inti();
				

	}

}
