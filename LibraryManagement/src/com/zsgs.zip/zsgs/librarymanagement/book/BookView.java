package com.zsgs.librarymanagement.book;

import java.util.List;
import java.util.Scanner;

import com.zsgs.librarymanagement.model.Book;

public class BookView {

	private BookModel bookModel;
	
	public BookView() {
		
		bookModel = new BookModel(this);
	}
	
	public void init() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the Number of book U want to add : ");
		int n = scanner.nextInt();
		for (int i = 1; i <= n; i++) {

			System.out.print("Enter the "+ i +" book Info ");
			Book book = new Book();
			System.out.print("Enter Name : ");
			book.setName(scanner.next());
			System.out.print("Enter Id : ");
			book.setId(scanner.next());
			System.out.print("Enter Author Name : ");
			book.setAuthor(scanner.next());
			System.out.print("Ener Enter Publication : ");
			book.setPublication(scanner.next());
			System.out.print("Enter Edition : ");
			book.setEdition(scanner.next());
			System.out.print("Enter Journer : ");
			book.setJourner(scanner.next());
			System.out.print("Ener Volume : ");
			book.setVolume(scanner.nextInt());					
			bookModel.addLibraryInfo(book);
		}
		bookModel.getLibraryInfo();	
		
	}
	
	public void showBooksInfo(List<Book> books) {
		
		for (int i = 0; i < books.size(); i++) {
			System.out.println();
			System.out.println((i+1)+" Book Info");
			System.out.println("Book Info "+(i+1));
			System.out.println("Enter Name : " +  books.get(i).getName());
			System.out.println("Enter Id : " + books.get(i).getId());
			System.out.println("Enter Author Name : " + books.get(i).getAuthor());
			System.out.println("Ener Enter Publication : " + books.get(i).getPublication());
			System.out.println("Enter Edition : " + books.get(i).getEdition());
			System.out.println("Enter Journer : " + books.get(i).getJourner());
			System.out.println("Ener Volume : " + books.get(i).getVolume());
		}
		removeBook();
	}
	
	public void removeBook() {
		
		boolean isRemoveBook = true;
		Scanner scanner = new Scanner(System.in);
		do {
			
			System.out.println("If You want to remove Book enter option number");
			String choich;
			System.out.println("1 -> Yes");			
			System.out.println("2 -> No");
			choich = scanner.next();
			
			switch (choich) {
			case "1":
				System.out.print("Enter Book Id : ");
				String bookId = scanner.next();
				bookModel.removeBook(bookId);
				break;
			case "2":
				isRemoveBook = false;
				break;

			default:
				System.out.println("Enter option is in-correct");
				break;
			}
			
		} while (isRemoveBook);
	}

	public void aletMessage(String message) {
		System.out.println(message);		
	}
}
