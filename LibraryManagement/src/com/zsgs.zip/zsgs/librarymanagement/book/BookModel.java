package com.zsgs.librarymanagement.book;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import com.zsgs.librarymanagement.model.Book;

class BookModel {

	private BookView bookView;
	List<Book> books;

	public BookModel(BookView bookView) {
		books = new ArrayList<Book>();
		this.bookView = bookView;
	}

	public void addLibraryInfo(Book book) {
		books.add(book);
	}

	public void getLibraryInfo() {
		bookView.showBooksInfo(books);
	}

	public void removeBook(String bookId) {
		boolean isBookRemoved = false;

		for (int i = 0; i < books.size(); i++) {

			if (books.get(i).getId().equals(bookId)) {
				books.remove(i);
				isBookRemoved = true;
				break;
			}
		}

		if (isBookRemoved) {
			bookView.aletMessage("Book Removed Successfully");
		} else {
			System.out.println("Book not found");
		}
	}
}