package com.zsgs.librarymanagement.addnewuser;

public class AddNewCustomerAccountModel {
	
	private AddNewCustomerAccountView addNewCustomerAccountView;
	
	AddNewCustomerAccountModel(AddNewCustomerAccountView addNewCustomerAccountView) {
		this.addNewCustomerAccountView = addNewCustomerAccountView;
	}
}
