package com.zsgs.librarymanagement.addnewuser;

public class AddNewCustomerAccountView {

	private AddNewCustomerAccountModel addNewCustomerAccountModel;
	
	AddNewCustomerAccountView() {
		this.addNewCustomerAccountModel = new AddNewCustomerAccountModel(this);
	}
}
