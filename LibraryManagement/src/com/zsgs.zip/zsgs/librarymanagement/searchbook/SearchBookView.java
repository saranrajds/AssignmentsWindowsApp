package com.zsgs.librarymanagement.searchbook;

public class SearchBookView {

	private SearchBookModel searchBookModel;
	
	SearchBookView() {
		
		this.searchBookModel = new SearchBookModel(this);
	}
}
