package com.zsgs.librarymanagement.searchbook;

public class SearchBookModel {

	private SearchBookView searchBookView;
	
	public SearchBookModel(SearchBookView searchBookView) {
		this.searchBookView = searchBookView;
	}
	
	

	
}
