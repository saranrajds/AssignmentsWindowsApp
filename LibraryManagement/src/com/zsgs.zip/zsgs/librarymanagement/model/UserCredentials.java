package com.zsgs.librarymanagement.model;

public class UserCredentials {

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public long getPassword() {
		return password;
	}
	public void setPassword(long password) {
		this.password = password;
	}
	
	private String userId;
	private long password;
}
