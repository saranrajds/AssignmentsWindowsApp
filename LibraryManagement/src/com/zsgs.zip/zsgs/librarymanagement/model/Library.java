package com.zsgs.librarymanagement.model;

import java.util.List;

public class Library {

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public List<UserCredentials> getAdminUsers() {
		return adminUsers;
	}
	public void setAdminUsers(List<UserCredentials> adminUsers) {
		this.adminUsers = adminUsers;
	}
	
	private String name;
	private String id;
	private String emailId;
	private String address;
	private long phoneNo;
	private List<UserCredentials> adminUsers;
	 
}
