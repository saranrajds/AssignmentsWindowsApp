package com.zsgs.librarymanagement.librarysetup;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.zsgs.librarymanagement.model.Library;
import com.zsgs.librarymanagement.model.UserCredentials;

public class LibrarySetupView {

	private LibrarySetupModel librarySetupModel;
	
	public LibrarySetupView() {
		librarySetupModel = new LibrarySetupModel(this);
	}

	public void init() {
		Scanner scanner = new Scanner(System.in);
		Library libraryInfo = new Library();
		System.out.print("Enter thr Name : ");
		libraryInfo.setName(scanner.next());
		System.out.print("Enter the Id : ");
		libraryInfo.setId(scanner.next());
		System.out.print("Enter the Phone No : ");
		libraryInfo.setPhoneNo(scanner.nextLong());
		System.out.print("Enter the Email Id : ");
		libraryInfo.setEmailId(scanner.next());
		System.out.print("Enter thr adddress : ");
		libraryInfo.setAddress(scanner.next());
		System.out.print("Enter the Number of Users : ");
		int n = scanner.nextInt();	
		
		List<UserCredentials> credentials = new ArrayList<UserCredentials>();
		
		for (int i = 0; i < n; i++) {
			
			UserCredentials credential = new UserCredentials();
			System.out.print("Enter the "+ i+1 +" User Id : ");
			credential.setUserId(scanner.next());
			System.out.print("Enter the "+ i+1 +" User Password : ");
			credential.setPassword(scanner.nextLong());
			credentials.add(credential);
		}
		
		libraryInfo.setAdminUsers(credentials);
		
		librarySetupModel.addLibraryInfo(libraryInfo);
		librarySetupModel.getLibraryInfo();
//		scanner.close();
	}

	public void showLibraryInfo(Library libraryInfo) {
		
		System.out.println("Name : "+libraryInfo.getName());
		System.out.println("Id : "+ libraryInfo.getId());
		System.out.println("Phone No : "+libraryInfo.getPhoneNo());
		System.out.println("Email Id : "+libraryInfo.getEmailId());
		System.out.println("Adddress : "+libraryInfo.getAddress());
		System.out.println("Number of Users : " + libraryInfo.getAdminUsers().size());
		
		for (int i = 0; i < libraryInfo.getAdminUsers().size(); i++) {
			System.out.println("User Name "+(i+1)+" : "+libraryInfo.getAdminUsers().indexOf(i));
		}
	}
}
