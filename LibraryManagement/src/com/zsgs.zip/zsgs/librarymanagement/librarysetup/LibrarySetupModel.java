package com.zsgs.librarymanagement.librarysetup;

import com.zsgs.librarymanagement.model.Library;

class LibrarySetupModel {

	private LibrarySetupView librarySetupView;
	Library library;
	public LibrarySetupModel(LibrarySetupView librarySetupView) {
		
		this.librarySetupView = librarySetupView;
		library = new Library();
	}

	public void addLibraryInfo(Library libraryInfo) {
		library = libraryInfo;
//		librarySetupView.showLibraryInfo(libraryInfo);
	}
	
	protected void getLibraryInfo() {
		librarySetupView.showLibraryInfo(library);
	}
	


}
