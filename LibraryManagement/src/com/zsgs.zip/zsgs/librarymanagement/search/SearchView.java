package com.zsgs.librarymanagement.search;

public class SearchView {

	private SearchModel searchModel;
	
	SearchView() {
		searchModel = new SearchModel(this);
	}
}
