package com.zsgs.librarymanagement.search;

public class SearchModel {

	private SearchView searchView;
	
	public SearchModel(SearchView searchView) {
		this.searchView = searchView;
	}

	
}
