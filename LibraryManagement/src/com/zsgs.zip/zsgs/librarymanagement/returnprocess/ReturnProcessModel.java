package com.zsgs.librarymanagement.returnprocess;

public class ReturnProcessModel {

	private ReturnProcessView returnProcessView;
	
	public ReturnProcessModel(ReturnProcessView returnProcessView) {
		this.returnProcessView = returnProcessView;
	}

}
