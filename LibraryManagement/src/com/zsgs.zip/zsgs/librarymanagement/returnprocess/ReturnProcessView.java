package com.zsgs.librarymanagement.returnprocess;

public class ReturnProcessView {

	private ReturnProcessModel returnProcessModel;
	
	ReturnProcessView() {
		this.returnProcessModel = new ReturnProcessModel(this);
	}
}
