package com.zsgs.librarymanagement.login;

import java.util.Scanner;

import com.zsgs.librarymanagement.book.BookView;
import com.zsgs.librarymanagement.librarysetup.LibrarySetupView;

public class LoginView {

	private LoginModel loginModel;

	public LoginView() {
		loginModel = new LoginModel(this);
	}

	public void inti() {

		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter UserName : ");
		String userName = scanner.next();
		System.out.print("Enter Password : ");
		String password = scanner.next();
//		scanner.close();
		loginModel.isValidate(userName, password);
	}

	public void alertMessage(String message) {
		System.out.println(message);
	}

	public void onSuccessAlert(String message) {
		System.out.println(message);
//		LibrarySetupView librarySetupView = new LibrarySetupView();
//		librarySetupView.init();	
		BookView bookView = new BookView();;
		bookView.init();
	}
}
