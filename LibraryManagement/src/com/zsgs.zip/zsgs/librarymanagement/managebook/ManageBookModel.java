package com.zsgs.librarymanagement.managebook;

class ManageBookModel {
	
	private ManageBookView manageBookView;

	ManageBookModel(ManageBookView manageBookView) {
		this.manageBookView = manageBookView;
	}
}
