package com.zsgs.librarymanagement.managebook;

public class ManageBookView {
	
	private ManageBookModel manageBookModel;
	
	public ManageBookView() {
		manageBookModel = new ManageBookModel(this);
	}

	public void init() {
		
	}
}
